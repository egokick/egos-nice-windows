#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [string]$InstallDirectory = "$env:ProgramFiles\Taildesk\Admin"
)

$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'App'
if (-not (Test-Path (Join-Path $source 'Taildesk.Admin.exe'))) {
    throw 'The App folder is missing. Extract the complete Taildesk command-center ZIP first.'
}

function Assert-ValidPublisher {
    param([string]$Path, [string[]]$PublisherTerms)
    $signature = Get-AuthenticodeSignature -LiteralPath $Path
    if ($signature.Status -ne 'Valid') {
        throw "Invalid Authenticode signature on $([IO.Path]::GetFileName($Path)): $($signature.Status)"
    }
    $subject = $signature.SignerCertificate.Subject
    if (-not ($PublisherTerms | Where-Object { $subject -match [regex]::Escape($_) })) {
        throw "Unexpected publisher on $([IO.Path]::GetFileName($Path)): $subject"
    }
}

function Install-Tailscale {
    $cli = "$env:ProgramFiles\Tailscale\tailscale.exe"
    if (Test-Path $cli) { return $cli }
    Write-Host 'Downloading Tailscale from tailscale.com...'
    $installer = Join-Path $env:TEMP 'taildesk-tailscale-setup.exe'
    Invoke-WebRequest 'https://pkgs.tailscale.com/stable/tailscale-setup-full-latest.exe' -OutFile $installer -UseBasicParsing
    Assert-ValidPublisher $installer @('Tailscale')
    $process = Start-Process $installer -ArgumentList '/quiet', '/norestart' -Wait -PassThru
    Remove-Item $installer -Force -ErrorAction SilentlyContinue
    if ($process.ExitCode -notin @(0, 3010)) { throw "Tailscale installer returned $($process.ExitCode)." }
    if (-not (Test-Path $cli)) { throw 'Tailscale installed, but tailscale.exe was not found.' }
    return $cli
}

function Install-RustDesk {
    $client = "$env:ProgramFiles\RustDesk\rustdesk.exe"
    if (Test-Path $client) { return $client }
    Write-Host 'Downloading the current official RustDesk release...'
    $release = Invoke-RestMethod 'https://api.github.com/repos/rustdesk/rustdesk/releases/latest' -Headers @{ 'User-Agent' = 'Taildesk-Installer/1.0' }
    $architecture = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'aarch64' } else { 'x86_64' }
    $asset = $release.assets | Where-Object { $_.name -match $architecture -and $_.name.EndsWith('.exe') -and $_.name -notmatch 'portable' } | Select-Object -First 1
    if (-not $asset) { throw "No official RustDesk $architecture Windows installer was found." }
    $installer = Join-Path $env:TEMP $asset.name
    Invoke-WebRequest $asset.browser_download_url -OutFile $installer -UseBasicParsing
    Assert-ValidPublisher $installer @('RustDesk', 'PURSLANE')
    $process = Start-Process $installer -ArgumentList '--silent-install' -Wait -PassThru
    Remove-Item $installer -Force -ErrorAction SilentlyContinue
    if ($process.ExitCode -ne 0) { throw "RustDesk installer returned $($process.ExitCode)." }
    if (-not (Test-Path $client)) { throw 'RustDesk installed, but rustdesk.exe was not found.' }
    return $client
}

function New-Shortcut {
    param([string]$Target, [string]$Path)
    $directory = Split-Path $Path
    if (-not (Test-Path -LiteralPath $directory)) {
        New-Item -Path $directory -ItemType Directory -Force | Out-Null
    }
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $Target
    $shortcut.WorkingDirectory = Split-Path $Target
    $shortcut.Description = 'Taildesk command center'
    $shortcut.Save()
}

function Expand-InteractivePath {
    param(
        [AllowNull()][object]$Value,
        [Parameter(Mandatory)][string]$ProfilePath,
        [Parameter(Mandatory)][string]$FallbackRelativePath,
        [Parameter(Mandatory)][hashtable]$Variables
    )

    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) {
        return Join-Path $ProfilePath $FallbackRelativePath
    }

    $expanded = [string]$Value
    for ($pass = 0; $pass -lt 4; $pass++) {
        $before = $expanded
        foreach ($entry in $Variables.GetEnumerator()) {
            $pattern = [regex]::Escape("%$($entry.Key)%")
            $replacement = [string]$entry.Value
            $expanded = [regex]::Replace(
                $expanded,
                $pattern,
                [System.Text.RegularExpressions.MatchEvaluator]{ param($match) $replacement },
                [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        }
        $expanded = [Environment]::ExpandEnvironmentVariables($expanded)
        if ($expanded -eq $before) { break }
    }

    if ($expanded.Contains('%')) {
        return Join-Path $ProfilePath $FallbackRelativePath
    }
    return $expanded
}

function Resolve-InteractiveUserProfile {
    # With over-the-shoulder UAC, WindowsIdentity and the process environment
    # describe the administrator whose credentials were entered, not the user
    # who launched Setup. Resolve the Explorer owner in this session instead.
    $sessionId = [Diagnostics.Process]::GetCurrentProcess().SessionId
    $accountName = $null
    $sid = $null
    try {
        $explorer = Get-CimInstance Win32_Process -Filter "Name='explorer.exe' AND SessionId=$sessionId" |
            Select-Object -First 1
        if ($null -ne $explorer) {
            $owner = Invoke-CimMethod -InputObject $explorer -MethodName GetOwner
            $ownerSid = Invoke-CimMethod -InputObject $explorer -MethodName GetOwnerSid
            if ($owner.ReturnValue -eq 0 -and -not [string]::IsNullOrWhiteSpace($owner.User)) {
                $accountName = if ([string]::IsNullOrWhiteSpace($owner.Domain)) {
                    $owner.User
                } else {
                    "$($owner.Domain)\$($owner.User)"
                }
            }
            if ($ownerSid.ReturnValue -eq 0) { $sid = $ownerSid.Sid }
        }
    } catch {
        # The Win32_ComputerSystem fallback below covers systems where CIM is
        # unavailable, while still preferring the same signed-in user.
    }

    if ([string]::IsNullOrWhiteSpace($accountName)) {
        try { $accountName = (Get-CimInstance Win32_ComputerSystem).UserName } catch { }
    }
    if ([string]::IsNullOrWhiteSpace($accountName)) {
        throw 'No signed-in interactive Windows user was found. Run this installer from the desktop session that will use Taildesk.'
    }
    if ([string]::IsNullOrWhiteSpace($sid)) {
        $account = New-Object -TypeName System.Security.Principal.NTAccount -ArgumentList $accountName
        $sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
    }

    $profileKeyPath = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$sid"
    $profileValue = (Get-ItemProperty -LiteralPath $profileKeyPath -ErrorAction Stop).ProfileImagePath
    if ([string]::IsNullOrWhiteSpace($profileValue)) {
        throw "The Windows profile for $accountName could not be found."
    }
    $profilePath = [Environment]::ExpandEnvironmentVariables([string]$profileValue)

    $profileRoot = [IO.Path]::GetPathRoot($profilePath).TrimEnd('\')
    $variables = @{
        USERPROFILE = $profilePath
        HOMEDRIVE = $profileRoot
        HOMEPATH = $profilePath.Substring($profileRoot.Length)
    }
    $accountParts = $accountName -split '\\', 2
    if ($accountParts.Length -eq 2) {
        $variables['USERDOMAIN'] = $accountParts[0]
        $variables['USERNAME'] = $accountParts[1]
    } else {
        $variables['USERNAME'] = $accountName
    }

    $environmentKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$sid\Environment")
    $shellKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$sid\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders")
    try {
        if ($null -ne $environmentKey) {
            foreach ($name in $environmentKey.GetValueNames()) {
                $value = $environmentKey.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                if ($null -ne $value) { $variables[$name] = [string]$value }
            }
        }

        $appDataValue = if ($null -ne $shellKey) {
            $shellKey.GetValue('AppData', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        } else { $null }
        $localAppDataValue = if ($null -ne $shellKey) {
            $shellKey.GetValue('Local AppData', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        } else { $null }
        $variables['APPDATA'] = Expand-InteractivePath $appDataValue $profilePath 'AppData\Roaming' $variables
        $variables['LOCALAPPDATA'] = Expand-InteractivePath $localAppDataValue $profilePath 'AppData\Local' $variables

        $desktopValue = if ($null -ne $shellKey) {
            $shellKey.GetValue('Desktop', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        } else { $null }
        $startupValue = if ($null -ne $shellKey) {
            $shellKey.GetValue('Startup', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        } else { $null }

        return [PSCustomObject]@{
            AccountName = $accountName
            Sid = $sid
            Desktop = Expand-InteractivePath $desktopValue $profilePath 'Desktop' $variables
            Startup = Expand-InteractivePath $startupValue $profilePath 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup' $variables
        }
    } finally {
        if ($null -ne $environmentKey) { $environmentKey.Dispose() }
        if ($null -ne $shellKey) { $shellKey.Dispose() }
    }
}

Write-Host 'Installing Taildesk command center...' -ForegroundColor Cyan
$interactiveProfile = Resolve-InteractiveUserProfile
Write-Host "Installing for signed-in user $($interactiveProfile.AccountName)."
$tailscale = Install-Tailscale
$null = Install-RustDesk

$statusText = (& $tailscale status --json 2>$null) -join "`n"
$running = $false
if ($statusText) {
    try {
        $statusObject = $statusText | ConvertFrom-Json
        $running = $statusObject.BackendState -eq 'Running' -and @($statusObject.Self.TailscaleIPs | Where-Object { $_ -match '^100\.' }).Count -gt 0
    } catch { $running = $false }
}
if (-not $running) {
    Write-Host 'A browser window will open so you can sign this laptop into Tailscale.' -ForegroundColor Yellow
    & $tailscale login
}
& $tailscale set "--operator=$($interactiveProfile.AccountName)" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Warning "Tailscale could not assign CLI operator access to $($interactiveProfile.AccountName). Taildesk can still run, but local Tailscale commands might require elevation."
}

if (Test-Path $InstallDirectory) {
    Get-Process 'Taildesk.Admin' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
}
New-Item $InstallDirectory -ItemType Directory -Force | Out-Null
Copy-Item (Join-Path $source '*') $InstallDirectory -Recurse -Force

$admin = Join-Path $InstallDirectory 'Taildesk.Admin.exe'
$desktopLink = Join-Path $interactiveProfile.Desktop 'Taildesk.lnk'
$startupLink = Join-Path $interactiveProfile.Startup 'Taildesk.lnk'
New-Shortcut $admin $desktopLink
New-Shortcut $admin $startupLink

$ipValue = & $tailscale ip -4 | Select-Object -First 1
if (-not $ipValue) { throw 'Tailscale did not assign an IPv4 address after login.' }
$ip = $ipValue.Trim()
if ($ip -match '^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.') {
    $deleteRuleArguments = @('advfirewall', 'firewall', 'delete', 'rule', 'name=Taildesk Coordinator (Tailscale only)')
    & netsh.exe @deleteRuleArguments | Out-Null
    $addRuleArguments = @(
        'advfirewall', 'firewall', 'add', 'rule',
        'name=Taildesk Coordinator (Tailscale only)', 'dir=in', 'action=allow',
        'protocol=TCP', 'localport=45830', "localip=$ip", 'remoteip=100.64.0.0/10',
        'profile=any', 'enable=yes'
    )
    & netsh.exe @addRuleArguments | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Windows could not create the Tailscale-only coordinator firewall rule.' }
} else {
    throw "Tailscale returned an address outside 100.64.0.0/10: $ip"
}

Write-Host "Installed for $($interactiveProfile.AccountName)." -ForegroundColor Green
Write-Host 'Close this elevated installer, then open Taildesk from that user''s desktop shortcut.' -ForegroundColor Green
Write-Host 'The command center starts at sign-in and remains available while that user stays signed in; locking the screen is fine.' -ForegroundColor Yellow
