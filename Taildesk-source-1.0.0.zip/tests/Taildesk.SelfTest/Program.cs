using System.Text.Json;
using Taildesk.Shared;

var tests = new (string Name, Action Body)[]
{
    ("tokens are random and hash comparisons work", TestTokens),
    ("invite JSON round-trips without losing role", TestInviteRoundTrip),
    ("path guard permits a child and blocks traversal", TestPathGuard),
    ("DPAPI current-user and machine scopes round-trip", TestDpapi)
};

var failures = new List<string>();
foreach (var test in tests)
{
    try
    {
        test.Body();
        Console.WriteLine($"PASS  {test.Name}");
    }
    catch (Exception exception)
    {
        failures.Add($"{test.Name}: {exception.Message}");
        Console.WriteLine($"FAIL  {test.Name}: {exception.Message}");
    }
}

if (failures.Count > 0)
{
    Environment.ExitCode = 1;
    Console.Error.WriteLine($"{failures.Count} Taildesk self-test(s) failed.");
}

static void TestTokens()
{
    var first = SecurityHelpers.CreateToken();
    var second = SecurityHelpers.CreateToken();
    Assert(first.Length >= 40, "token is too short");
    Assert(first != second, "two tokens unexpectedly matched");
    Assert(SecurityHelpers.FixedTimeEquals(SecurityHelpers.HashToken(first), SecurityHelpers.HashToken(first)), "equal hashes did not match");
    Assert(!SecurityHelpers.FixedTimeEquals(SecurityHelpers.HashToken(first), SecurityHelpers.HashToken(second)), "different hashes matched");
}

static void TestInviteRoundTrip()
{
    var invite = new InvitePayload
    {
        InviteId = Guid.NewGuid(),
        DeviceName = "Workshop PC",
        Role = DeviceRole.ControllerAndManaged,
        ExpiresAt = DateTimeOffset.UtcNow.AddMinutes(15),
        InviteSecret = SecurityHelpers.CreateToken(),
        TailscaleAuthKey = "tskey-auth-test",
        AgentToken = SecurityHelpers.CreateToken(),
        RustDeskPassword = SecurityHelpers.CreateHumanPassword(),
        ControllerToken = SecurityHelpers.CreateToken(),
        CoordinatorUrl = "http://100.100.100.100:45830",
        ExpectedTailnet = "example.test",
        AllowedRoots = ["Documents", "Pictures"]
    };
    var json = JsonSerializer.Serialize(invite, JsonDefaults.Options);
    var copy = JsonSerializer.Deserialize<InvitePayload>(json, JsonDefaults.Options);
    Assert(copy?.InviteId == invite.InviteId, "invite id changed");
    Assert(copy?.Role == DeviceRole.ControllerAndManaged, "role changed");
    Assert(copy?.AgentToken == invite.AgentToken, "agent token changed");
    Assert(copy?.ExpectedTailnet == invite.ExpectedTailnet, "expected tailnet changed");
    Assert(copy?.AllowedRoots.SequenceEqual(invite.AllowedRoots) == true, "shared roots changed");
}

static void TestPathGuard()
{
    var temporary = Path.Combine(Path.GetTempPath(), "taildesk-selftest-" + Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(temporary);
    try
    {
        var child = Path.Combine(temporary, "child");
        Directory.CreateDirectory(child);
        var guard = new PathGuard(new Dictionary<string, string> { ["test"] = temporary });
        Assert(guard.Resolve("test", "child") == Path.GetFullPath(child), "valid child did not resolve");
        AssertThrows<UnauthorizedAccessException>(() => guard.Resolve("test", ".."));
        AssertThrows<UnauthorizedAccessException>(() => guard.Resolve("test", "file.txt:stream", mustExist: false));
        AssertThrows<UnauthorizedAccessException>(() => guard.Resolve("test", "C:\\Windows", mustExist: false));
        AssertThrows<UnauthorizedAccessException>(() => guard.Resolve("test", "\\\\server\\share", mustExist: false));
    }
    finally
    {
        Directory.Delete(temporary, true);
    }
}

static void TestDpapi()
{
    if (!OperatingSystem.IsWindows()) return;
    var secret = SecurityHelpers.CreateToken();
    var user = SecretProtector.Protect(secret, SecretScope.CurrentUser);
    var machine = SecretProtector.Protect(secret, SecretScope.LocalMachine);
    Assert(SecretProtector.Unprotect(user, SecretScope.CurrentUser) == secret, "current-user DPAPI failed");
    Assert(SecretProtector.Unprotect(machine, SecretScope.LocalMachine) == secret, "machine DPAPI failed");
}

static void Assert(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
}

static void AssertThrows<TException>(Action action) where TException : Exception
{
    try { action(); }
    catch (TException) { return; }
    throw new InvalidOperationException($"expected {typeof(TException).Name}");
}
