# Taildesk

Taildesk is a Windows-native personal command center for a private fleet of Windows PCs. It combines:

- **Tailscale** for encrypted reachability, device presence, role enforcement, and exit-node routing.
- **RustDesk direct IP** for full remote control, including Windows Home machines that cannot host Microsoft RDP.
- **Taildesk Agent** for restricted file browsing, upload/download, and short-lived media streams.
- **Taildesk Admin** for invitations, device state, role changes, transfers, remote control, and VPN selection.

The application never opens a router port. The Agent (`45831`), coordinator (`45830`), and RustDesk direct listener (`21118`) bind to or are firewalled to Tailscale's `100.64.0.0/10` address space.

## Fast start

### 1. Build a Windows package

On a Windows 10/11 machine with the [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0):

```powershell
git clone <your-repository-url>
cd Taildesk
.\build.ps1 -Runtime win-x64
```

The output is `dist\Taildesk-CommandCenter-win-x64.zip`. The included GitHub Actions workflow can build both x64 and ARM64 packages without a local SDK.

### 2. Prepare the Tailscale policy

Before creating the OAuth client, open **Tailscale Admin → Access controls** and replace the default allow-all policy with [`config/tailnet-policy.hujson`](config/tailnet-policy.hujson). This is necessary because Tailscale permissions combine; leaving an allow-all rule would defeat managed-only isolation.

The policy defines mutually exclusive roles:

| Tag | Meaning |
|---|---|
| `tag:taildesk-hub` | The primary command-center laptop |
| `tag:taildesk-controller` | May control peers; may also be controlled |
| `tag:taildesk-managed` | May only be controlled |
| `tag:taildesk-exit` | May advertise an approved exit node |
| `tag:taildesk-provisioner` | OAuth credential owner; never assigned to an invited PC |

### 3. Create one Tailscale OAuth client

In **Tailscale Admin → Trust credentials**, create an OAuth client with tag `tag:taildesk-provisioner` and these write scopes:

- `auth_keys`
- `devices:core`
- `devices:routes`
- `policy_file`

Copy its client ID and secret. The secret is shown once. Taildesk stores it with Windows DPAPI for the current command-center user.

### 4. Install the command center

Extract the command-center ZIP from the Windows account that will operate Taildesk and run `Install-CommandCenter.ps1` as Administrator. It installs signed official Tailscale/RustDesk releases if needed, copies Taildesk to Program Files, creates desktop/startup shortcuts for the signed-in interactive account, and restricts coordinator traffic to the Tailscale network. If a standard user enters a different administrator account at UAC, the installer still targets the original interactive profile and assigns that account as the Tailscale CLI operator.

The installer deliberately does not launch Taildesk from its elevated token. When it finishes, close the PowerShell window and open the new **Taildesk** desktop shortcut as the normal signed-in user.

In Taildesk **Settings**:

1. Select **Detect** for this laptop's `100.x` address.
2. Enter the OAuth client ID and secret. Tailnet ID can remain `-`.
3. Save settings.
4. Select **Test API**, **Apply Taildesk policy**, **Tag this laptop as hub**, and **Firewall rule**.

Leave that Windows user signed in and Taildesk running; locking the screen is fine. Taildesk minimizes to the notification area and keeps the enrollment/sync coordinator available. The current coordinator is not a pre-logon Windows service: after a reboot, someone must sign in before it starts, and signing out or choosing **Exit** from the tray stops enrollment and secondary-controller sync.

### 5. Invite a target anywhere

Before the target accepts an invitation, confirm Taildesk is running in the primary laptop's notification area. Enrollment requires the coordinator during the invitation's 15-minute validity window.

In **Invitations**, enter a machine name, select the folders that machine will share, and choose:

- **Managed only** — this PC can be controlled but cannot initiate Taildesk/RustDesk sessions to peers.
- **Controller + managed** — this PC may also run the Taildesk controller.

Taildesk produces a personalized ZIP. Send it through any channel you trust. On the target:

1. Extract the complete ZIP.
2. Run `Taildesk.Setup.exe` and approve UAC.
   If the PC is already signed into Tailscale, Setup asks before signing that identity out and re-enrolling it so the single-use invitation is consumed and its exact tailnet/tags are enforced.
3. Setup installs Tailscale and RustDesk, joins with the single-use 15-minute key, configures direct access, installs the Agent as a SYSTEM startup task, creates Tailscale-only firewall rules, and enrolls back to the laptop.
4. Delete the invitation ZIP after setup. `invite.tdinvite` is automatically removed after a successful install.

Only the folders checked when the invitation was created are exposed through Taildesk's remote file browser. At least one folder must be selected.

This personal, offline-first build uses that personalized ZIP as the invitation/acceptance artifact. It does not include a public cloud service that hosts secret-bearing bundles as clickable web links.

The same process works on the local LAN or across the internet. Taildesk always addresses peers through their Tailscale IP; Tailscale automatically chooses a direct LAN path when possible.

## Implemented capabilities

- Online/offline and agent-health status
- RustDesk full control by direct Tailscale IP
- Remote shared-root browsing, upload, download, folder creation, and deletion
- Range-enabled, five-minute signed media/document streams
- Current-session transfer status and history
- Personalized one-time invitation bundles with selectable shared folders
- Managed-only/controller role changes backed by Tailscale device tags
- Automatic peer credential rotation after controller demotion
- Remote-first Tailscale identity revocation and device removal
- Exit-node advertising, route approval, selection, and stop
- Secondary-controller registry sync through the hub
- Windows 10/11 Home, Pro, and Enterprise targets (x64 and ARM64 packages)

## Validation status

The repository includes deterministic builds, a Windows CI matrix, embedded policy assertions, C#/XAML structural validation, and foundational self-tests. It has not been end-to-end exercised on real Windows machines in the environment that produced this source archive. See the exact [`validation record`](docs/VALIDATION.md). Before treating a build as production-ready, complete the Windows Home, reboot, RustDesk control, file-transfer, role-change, removal, and exit-route checks in [`docs/SECURITY.md`](docs/SECURITY.md), then sign the published executables.

## Operational notes

- Taildesk itself is not Authenticode-signed. Sign the three published executables with your own code-signing certificate before distributing them outside your own machines. The installer refuses downloaded Tailscale/RustDesk binaries without a valid expected publisher signature.
- RustDesk's password is copied to the local clipboard when launching direct control and automatically cleared after 60 seconds if unchanged.
- The target Agent exposes only fixed operations. There is no remote shell or arbitrary command endpoint.
- Setup resolves the active interactive Windows profile even when a standard user enters separate administrator credentials at UAC, so shared folders and controller shortcuts belong to the intended user.
- File access is limited to configured root IDs. Absolute, UNC, device, alternate data stream, traversal, symlink, and junction escapes are rejected.
- The primary coordinator is part of the tray-resident Admin process. It starts only after its configured Windows user signs in and remains available while that user stays signed in and Taildesk is running. It is not available before sign-in, after sign-out, or after **Exit**. Tailscale and each target Agent do start before sign-in.
- A true pre-logon coordinator would require a separate Windows service, machine-scoped coordinator state, and authenticated IPC with the per-user WPF app. This source release does not install that service or store a Windows password to simulate one.
- Invitation bundles contain short-lived secrets. Treat them like temporary passwords and delete expired/canceled copies.

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) and [`docs/SECURITY.md`](docs/SECURITY.md) for implementation and trust-boundary details.

## Upstream references

- [Tailscale OAuth clients](https://tailscale.com/docs/features/oauth-clients) and [auth keys](https://tailscale.com/docs/features/access-control/auth-keys)
- [Tailscale CLI](https://tailscale.com/docs/reference/tailscale-cli), [tailnet policy syntax](https://tailscale.com/docs/reference/syntax/policy-file), and [Windows exit-node setup](https://tailscale.com/docs/features/exit-nodes/how-to/setup?tab=windows)
- [Tailscale's RustDesk direct-IP guide](https://tailscale.com/docs/solutions/access-remote-desktops-with-rustdesk)
- [RustDesk Windows deployment](https://rustdesk.com/docs/en/self-host/client-deployment/) and [advanced client settings](https://rustdesk.com/docs/en/self-host/client-configuration/advanced-settings/)
