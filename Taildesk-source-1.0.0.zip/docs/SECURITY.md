# Security model

## Trust boundaries

- The primary laptop and Tailscale control plane decide role/tag membership.
- Taildesk's bearer token is a second application-layer check, not a replacement for Tailscale grants.
- Managed-only machines receive no source grant to Agent or RustDesk ports. They can reach the hub's coordinator port only so a one-time invite can enroll; registry sync separately requires a valid controller token and a current controller role.
- Nothing listens on a public or LAN IP by design. Do not add router port forwarding.

## File API controls

- Requests name a configured root ID and relative path; arbitrary absolute paths are unsupported.
- Rooted, UNC, device, alternate-data-stream, and escaping paths are rejected.
- Existing path components with `FileAttributes.ReparsePoint` are rejected to block symlink/junction escapes.
- Uploads stream into a random partial file inside the validated destination, flush, then atomically move into place. Canceled uploads remove the partial file.
- Two concurrent uploads are allowed per Agent; Kestrel request bodies are capped at 20 GiB.
- Media URLs carry an HMAC over HTTP method, root, relative path, expiry, and nonce, expire after five minutes, and revalidate the path when opened.

## Invite controls

- Tailscale keys are non-reusable, preauthorized, tagged, and expire after 900 seconds.
- A local role edit cannot upgrade access because the tag is embedded in the auth key and the coordinator uses its stored invitation role.
- The OAuth client secret and other devices' secrets never enter a bundle.
- The invitation secret is stored as a hash on the hub. The target keeps it DPAPI-protected only until enrollment succeeds.
- Enrollment and cancellation share one state gate, and the coordinator confirms that the one-use Tailscale key is absent/revoked before committing enrollment.
- Canceling an invitation revokes its Tailscale key and deletes the command center's local copy. The operator must still delete copies already sent elsewhere. Expired keys cease working automatically.

## RustDesk controls

- A unique permanent password is generated per target.
- Direct-IP access is enabled on port 21118; LAN discovery and remote configuration changes are disabled.
- RustDesk's whitelist is restricted to `100.64.0.0/10`; Tailscale grants provide the actual controller/managed authorization.
- Windows Firewall allows the direct port only at the target's Tailscale local IP and only from the Tailscale address range.
- Taildesk launches RustDesk against the Tailscale IP and places the password on the local clipboard for 60 seconds instead of exposing it in a process command line.

## Remaining risks

- A local administrator on any PC can replace binaries, read machine-level secrets, or install another remote-control product. Taildesk does not defend a machine against its own local administrators.
- The build output is unsigned until you apply your own Authenticode certificate.
- Secondary controllers receive per-target secrets in memory during a sync. Removing their controller tag stops reachability immediately; Taildesk additionally rotates target credentials.
- The coordinator uses HTTP inside the already encrypted Tailscale tunnel. Its bind address and firewall rule must remain Tailscale-only.
- Role, credential-rotation, and exit-node Agent actions additionally require the request to originate from the configured primary hub's Tailscale IP.
- The coordinator is not a Windows service. Its availability depends on the primary interactive user remaining signed in with Taildesk running; locking that session is supported. Do not enable insecure automatic Windows logon merely to approximate pre-logon service availability.
- Command-center installation may be elevated with a different administrator identity, but shortcuts and Tailscale operator access are resolved to the Explorer owner in the invoking session. Admin itself must subsequently be launched unelevated by that interactive user so its current-user DPAPI secrets and configuration stay in the intended profile.

## Release checklist

1. Build on a clean, patched Windows runner.
2. Run `Taildesk.SelfTest` and test real Windows Home targets.
3. Sign Admin, Agent, and Setup with Authenticode; timestamp signatures.
4. Scan all published binaries.
5. Confirm the tailnet policy tests pass and no allow-all ACL/grant remains.
6. Verify LAN IPs do not expose ports 45830, 45831, or 21118.
7. Test reboot/logoff, upload cancellation, expired/canceled invite races, role demotion, device removal, and offline credential/shortcut synchronization.
8. From a standard-user desktop, install with different administrator credentials at UAC; verify the shortcut, startup entry, Admin data, and Tailscale operator all belong to the original interactive user.
