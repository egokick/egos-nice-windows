using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using Taildesk.Shared;

namespace Taildesk.Admin;

public sealed class MainViewModel : INotifyPropertyChanged
{
    private readonly AdminState _state;
    private readonly TailscaleApiClient _tailscale;
    private readonly AgentClient _agents;
    private readonly TransferManager _transfers;
    private DeviceRecord? _selectedDevice;
    private string _status = "Ready";
    private bool _busy;

    public MainViewModel(AdminState state, TailscaleApiClient tailscale, AgentClient agents, TransferManager transfers)
    {
        _state = state;
        _tailscale = tailscale;
        _agents = agents;
        _transfers = transfers;
        Transfers = transfers.Items;
    }

    public ObservableCollection<DeviceRecord> Devices { get; } = [];
    public ObservableCollection<InviteRecord> Invites { get; } = [];
    public ObservableCollection<TransferRow> Transfers { get; }
    public ObservableCollection<string> LogLines { get; } = [];
    public AdminConfig Config => _state.Config;
    public bool IsPrimary => Config.Mode == AdminMode.Primary;
    public DeviceRecord? SelectedDevice { get => _selectedDevice; set { _selectedDevice = value; Changed(); } }
    public string Status { get => _status; set { _status = value; Changed(); } }
    public bool Busy { get => _busy; set { _busy = value; Changed(); } }

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        ReplaceInvites();
        if (Config.SetupComplete) await RefreshAsync(cancellationToken);
    }

    public async Task RefreshAsync(CancellationToken cancellationToken = default)
    {
        if (Busy || !Config.SetupComplete) return;
        Busy = true;
        Status = "Refreshing devices…";
        try
        {
            if (Config.Mode == AdminMode.Secondary)
            {
                await SyncSecondaryAsync(cancellationToken);
            }
            else
            {
                await RefreshPrimaryTailnetAsync(cancellationToken);
            }

            var currentDevices = Devices.ToArray();
            await Task.WhenAll(currentDevices.Select(device => ProbeAgentAsync(device, cancellationToken)));
            foreach (var device in currentDevices)
            {
                if (Config.Mode == AdminMode.Primary && device.PendingRoleSync && device.State == DeviceConnectionState.Online)
                {
                    try
                    {
                        await _agents.SetRoleAsync(device, GetAgentToken(device), device.Role, cancellationToken);
                        device.PendingRoleSync = false;
                    }
                    catch (Exception exception)
                    {
                        Log($"Role shortcut sync pending for {device.Name}: {exception.Message}");
                    }
                }
                if (Config.Mode == AdminMode.Primary && device.PendingCredentialRotation && device.State == DeviceConnectionState.Online)
                {
                    await RotateOneAsync(device, cancellationToken);
                }
            }
            ReplaceDevices(Config.Mode == AdminMode.Primary ? Config.Devices : Devices.ToArray());
            if (Config.Mode == AdminMode.Primary) await _state.SaveAsync(cancellationToken);
            Status = $"{Devices.Count(device => device.State == DeviceConnectionState.Online)} online / {Devices.Count} enrolled";
        }
        catch (Exception exception)
        {
            Log("Refresh failed: " + exception.Message);
            Status = "Refresh failed";
        }
        finally
        {
            Busy = false;
        }
    }

    public string GetAgentToken(DeviceRecord device) => SecretProtector.Unprotect(device.AgentTokenProtected);
    public string GetRustDeskPassword(DeviceRecord device) => SecretProtector.Unprotect(device.RustDeskPasswordProtected);

    public async Task ChangeRoleAsync(DeviceRecord device, DeviceRole newRole, CancellationToken cancellationToken = default)
    {
        RequirePrimary();
        if (device.Role == newRole) return;
        var oldToken = GetAgentToken(device);
        if (newRole == DeviceRole.ManagedOnly)
        {
            await _tailscale.SetDeviceRoleAsync(device.TailnetDeviceId, newRole, device.AdvertisesExitNode, cancellationToken);
            device.Role = newRole;
            device.PendingRoleSync = true;
            foreach (var target in Config.Devices) target.PendingCredentialRotation = true;
            await _state.SaveAsync(cancellationToken);
            try
            {
                await _agents.SetRoleAsync(device, oldToken, newRole, cancellationToken);
                device.PendingRoleSync = false;
            }
            catch (Exception exception)
            {
                Log($"Network access was revoked; local controller shortcuts will be removed when {device.Name} is online: {exception.Message}");
            }
            foreach (var target in Config.Devices.Where(target => target.State == DeviceConnectionState.Online).ToArray())
            {
                try { await RotateOneAsync(target, cancellationToken); }
                catch (Exception exception) { Log($"Credential rotation pending for {target.Name}: {exception.Message}"); }
            }
            await _state.SaveAsync(cancellationToken);
            Log($"{device.Name} is now managed-only. Controller reachability was revoked; peer credentials were rotated or queued for rotation.");
        }
        else
        {
            await _agents.SetRoleAsync(device, oldToken, newRole, cancellationToken);
            await _tailscale.SetDeviceRoleAsync(device.TailnetDeviceId, newRole, device.AdvertisesExitNode, cancellationToken);
            device.Role = newRole;
            device.PendingRoleSync = false;
            await _state.SaveAsync(cancellationToken);
            Log($"{device.Name} can now open Taildesk and control permitted machines.");
        }
        ReplaceDevices(Config.Devices);
    }

    public async Task RemoveDeviceAsync(DeviceRecord device, CancellationToken cancellationToken = default)
    {
        RequirePrimary();
        if (Busy)
        {
            throw new InvalidOperationException("Wait for the current device refresh or operation to finish.");
        }

        Busy = true;
        var displayName = string.IsNullOrWhiteSpace(device.Name) ? device.HostName : device.Name;
        Status = $"Revoking {displayName}…";
        var tailscaleDeleted = false;
        var remoteStateResolved = false;
        var registryCommitted = false;
        var removedController = false;
        var bundleDeleteFailures = new List<string>();
        DeviceRecord[] rotationTargets = [];

        try
        {
            await _state.InviteGate.WaitAsync(cancellationToken);
            try
            {
                var registered = Config.Devices.FirstOrDefault(item => item.Id == device.Id)
                                 ?? throw new InvalidOperationException("This device is no longer enrolled in Taildesk.");
                if (string.IsNullOrWhiteSpace(registered.TailnetDeviceId))
                {
                    throw new InvalidOperationException(
                        "This registry entry has no Tailscale device ID, so Taildesk cannot safely revoke it. Refresh the device list and try again.");
                }

                displayName = string.IsNullOrWhiteSpace(registered.Name) ? registered.HostName : registered.Name;
                removedController = registered.Role == DeviceRole.ControllerAndManaged;

                // Revoke network membership before forgetting the credentials.
                // If this fails, the device remains visible and manageable here.
                tailscaleDeleted = await _tailscale.DeleteDeviceAsync(registered.TailnetDeviceId, cancellationToken);
                remoteStateResolved = true;
                Config.Devices.RemoveAll(item => item.Id == registered.Id);

                foreach (var invite in Config.Invites.Where(item => item.EnrolledDeviceId == registered.Id))
                {
                    invite.AgentTokenProtected = string.Empty;
                    invite.RustDeskPasswordProtected = string.Empty;
                    invite.ControllerTokenProtected = string.Empty;
                    if (string.IsNullOrWhiteSpace(invite.BundlePath)) continue;

                    try
                    {
                        if (File.Exists(invite.BundlePath)) File.Delete(invite.BundlePath);
                        invite.BundlePath = string.Empty;
                    }
                    catch (Exception exception)
                    {
                        bundleDeleteFailures.Add($"{invite.BundlePath}: {exception.Message}");
                    }
                }

                if (removedController)
                {
                    foreach (var peer in Config.Devices) peer.PendingCredentialRotation = true;
                    rotationTargets = Config.Devices
                        .Where(peer => peer.State == DeviceConnectionState.Online)
                        .ToArray();
                }

                // Remote deletion is irreversible, so finish the local commit even
                // if the initiating UI cancellation token changes at this point.
                await _state.SaveAsync(CancellationToken.None);
                registryCommitted = true;
            }
            finally
            {
                _state.InviteGate.Release();
            }

            foreach (var target in rotationTargets)
            {
                try
                {
                    await RotateOneAsync(target, cancellationToken);
                }
                catch (Exception exception)
                {
                    Log($"Credential rotation remains pending for {target.Name}: {exception.Message}");
                }
            }

            ReplaceDevices(Config.Devices);
            ReplaceInvites();
            foreach (var failure in bundleDeleteFailures)
            {
                Log("An associated invitation bundle could not be deleted: " + failure);
            }

            Status = bundleDeleteFailures.Count == 0
                ? $"{displayName} removed from Taildesk"
                : $"{displayName} removed; delete the listed invitation bundle manually";
            Log(tailscaleDeleted
                ? $"Revoked {displayName} in Tailscale and removed its Taildesk registry entry."
                : $"Tailscale already no longer listed {displayName}; removed its stale Taildesk registry entry.");
            if (removedController)
            {
                Log("Peer credential rotation was requested; unreachable peers remain marked for rotation on reconnect.");
            }
        }
        catch (Exception exception) when (remoteStateResolved && !registryCommitted)
        {
            Status = $"{displayName} revoked; registry cleanup needs attention";
            throw new InvalidOperationException(
                $"{displayName} was revoked in Tailscale, but Taildesk could not save the local registry cleanup. Restart Taildesk and remove the stale entry again.",
                exception);
        }
        catch
        {
            Status = $"Could not remove {displayName}";
            throw;
        }
        finally
        {
            Busy = false;
        }
    }

    public async Task SetExitAdvertisementAsync(DeviceRecord device, bool enabled, CancellationToken cancellationToken = default)
    {
        RequirePrimary();
        var token = GetAgentToken(device);
        if (enabled)
        {
            await _agents.SetExitNodeAsync(device, token, true, cancellationToken);
            await _tailscale.SetDeviceRoleAsync(device.TailnetDeviceId, device.Role, exitNode: true, cancellationToken);
            await Task.Delay(1500, cancellationToken);
            await _tailscale.ApproveAdvertisedRoutesAsync(device.TailnetDeviceId, cancellationToken);
        }
        else
        {
            await _agents.SetExitNodeAsync(device, token, false, cancellationToken);
            await _tailscale.SetDeviceRoleAsync(device.TailnetDeviceId, device.Role, exitNode: false, cancellationToken);
        }
        device.AdvertisesExitNode = enabled;
        device.ExitNodeApproved = enabled;
        await _state.SaveAsync(cancellationToken);
        Log($"Exit-node service {(enabled ? "enabled" : "disabled")} on {device.Name}.");
    }

    public async Task UseExitNodeAsync(DeviceRecord device, CancellationToken cancellationToken = default)
    {
        if (!AgentClient.IsTailscaleIp(device.TailscaleIp)) throw new InvalidOperationException("The selected device has no valid Tailscale IPv4 address.");
        var tailscale = FindTailscale();
        var result = await ProcessRunner.RunAsync(tailscale,
            ["set", $"--exit-node={device.TailscaleIp}", "--exit-node-allow-lan-access=false"], TimeSpan.FromSeconds(30), cancellationToken);
        if (!result.Succeeded) throw new InvalidOperationException(result.StandardError.Trim());
        Status = $"VPN egress: {device.Name}";
        Log($"This machine is now using {device.Name} as its internet exit node.");
    }

    public async Task StopUsingExitNodeAsync(CancellationToken cancellationToken = default)
    {
        var result = await ProcessRunner.RunAsync(FindTailscale(), ["set", "--exit-node="], TimeSpan.FromSeconds(30), cancellationToken);
        if (!result.Succeeded) throw new InvalidOperationException(result.StandardError.Trim());
        Status = "VPN egress: local connection";
        Log("Stopped using a remote exit node.");
    }

    public void LaunchRemoteControl(DeviceRecord device)
    {
        if (!File.Exists(Config.RustDeskPath)) throw new FileNotFoundException("RustDesk was not found. Set its path in Settings.");
        if (!AgentClient.IsTailscaleIp(device.TailscaleIp)) throw new InvalidOperationException("The selected device has no valid Tailscale address.");
        var password = GetRustDeskPassword(device);
        System.Windows.Clipboard.SetText(password);
        var start = new ProcessStartInfo(Config.RustDeskPath) { UseShellExecute = true };
        start.ArgumentList.Add("--connect");
        start.ArgumentList.Add(device.TailscaleIp);
        Process.Start(start);
        Log($"Opened RustDesk direct control for {device.Name}; its password was copied to the clipboard.");
    }

    public async Task<InviteBundleResult> CreateInviteAsync(
        string deviceName,
        DeviceRole role,
        bool exitNode,
        IReadOnlyCollection<string> allowedRoots,
        CancellationToken cancellationToken = default)
    {
        RequirePrimary();
        var result = await new InviteBundleService(_state, _tailscale).CreateAsync(
            deviceName,
            role,
            exitNode,
            allowedRoots,
            cancellationToken);
        ReplaceInvites();
        Log($"Created single-use invite for {deviceName} with {allowedRoots.Count} shared folder(s). It expires in 15 minutes.");
        return result;
    }

    public async Task CancelInviteAsync(InviteRecord invite, CancellationToken cancellationToken = default)
    {
        RequirePrimary();
        var bundlePath = string.Empty;
        await _state.InviteGate.WaitAsync(cancellationToken);
        try
        {
            if (invite.RedeemedAt.HasValue) throw new InvalidOperationException("A redeemed invitation cannot be canceled; change or remove the enrolled device instead.");
            await _tailscale.RevokeKeyAsync(invite.TailscaleKeyId, cancellationToken);
            if (invite.RedeemedAt.HasValue) throw new InvalidOperationException("The device completed enrollment before cancellation; the invitation was not canceled.");
            bundlePath = invite.BundlePath;
            invite.ExpiresAt = DateTimeOffset.UtcNow;
            invite.BundlePath = string.Empty;
            await _state.SaveAsync(cancellationToken);
        }
        finally
        {
            _state.InviteGate.Release();
        }
        var bundleDeleted = true;
        try { if (File.Exists(bundlePath)) File.Delete(bundlePath); }
        catch (Exception exception)
        {
            bundleDeleted = false;
            Log($"Invitation was canceled, but its local bundle could not be deleted ({bundlePath}): {exception.Message}");
        }
        ReplaceInvites();
        Log(bundleDeleted
            ? $"Canceled the invitation for {invite.DeviceName} and removed its local bundle."
            : $"Canceled the invitation for {invite.DeviceName}; delete the old bundle manually.");
    }

    public async Task SavePrimarySettingsAsync(string tailnet, string clientId, string? clientSecret, string bindAddress,
        string inviteDirectory, string rustDeskPath, CancellationToken cancellationToken = default)
    {
        if (Config.Mode != AdminMode.Primary) throw new InvalidOperationException("This controller receives settings from the command center.");
        if (!AgentClient.IsTailscaleIp(bindAddress)) throw new InvalidOperationException("Coordinator address must be this laptop's 100.x Tailscale IPv4 address.");
        if (string.IsNullOrWhiteSpace(clientId)) throw new InvalidOperationException("Enter the Tailscale OAuth client ID.");
        if (string.IsNullOrWhiteSpace(clientSecret) && string.IsNullOrWhiteSpace(Config.OAuthClientSecretProtected))
            throw new InvalidOperationException("Enter the Tailscale OAuth client secret.");
        if (string.IsNullOrWhiteSpace(inviteDirectory)) throw new InvalidOperationException("Choose an invitation output folder.");
        if (string.IsNullOrWhiteSpace(rustDeskPath)) throw new InvalidOperationException("Choose the RustDesk executable path.");
        Config.Tailnet = string.IsNullOrWhiteSpace(tailnet) ? "-" : tailnet.Trim();
        Config.OAuthClientId = clientId.Trim();
        if (!string.IsNullOrWhiteSpace(clientSecret)) Config.OAuthClientSecretProtected = SecretProtector.Protect(clientSecret.Trim());
        Config.CoordinatorBindAddress = bindAddress.Trim();
        Config.CoordinatorUrl = $"http://{Config.CoordinatorBindAddress}:{Config.CoordinatorPort}";
        Config.InviteOutputDirectory = Environment.ExpandEnvironmentVariables(inviteDirectory.Trim());
        Config.RustDeskPath = Environment.ExpandEnvironmentVariables(rustDeskPath.Trim());
        Config.SetupComplete = true;
        Directory.CreateDirectory(Config.InviteOutputDirectory);
        await _state.SaveAsync(cancellationToken);
        Log("Command-center settings saved.");
    }

    public async Task ApplyTailnetPolicyAsync(CancellationToken cancellationToken = default)
    {
        RequirePrimary();
        await _tailscale.ApplyPolicyAsync(TailnetPolicy.Build(), cancellationToken);
        Log("Applied the strict Taildesk role policy to the tailnet.");
    }

    public async Task TagThisMachineAsHubAsync(CancellationToken cancellationToken = default)
    {
        var result = await ProcessRunner.RunAsync(FindTailscale(), ["set", "--advertise-tags=tag:taildesk-hub"], TimeSpan.FromSeconds(30), cancellationToken);
        if (!result.Succeeded) throw new InvalidOperationException(result.StandardError.Trim());
        Log("This machine now advertises tag:taildesk-hub.");
    }

    public async Task TestTailscaleApiAsync(CancellationToken cancellationToken = default)
    {
        await _tailscale.TestAsync(cancellationToken);
        Log("Tailscale API credentials are working.");
    }

    public void Log(string message)
    {
        System.Windows.Application.Current.Dispatcher.Invoke(() =>
        {
            LogLines.Insert(0, $"{DateTime.Now:HH:mm:ss}  {message}");
            while (LogLines.Count > 500) LogLines.RemoveAt(LogLines.Count - 1);
        });
    }

    private async Task RefreshPrimaryTailnetAsync(CancellationToken cancellationToken)
    {
        IReadOnlyList<TailscaleDeviceInfo> tailnet = [];
        try { tailnet = await _tailscale.GetDevicesAsync(cancellationToken); }
        catch (Exception exception) { Log("Tailscale inventory unavailable: " + exception.Message); }

        foreach (var device in Config.Devices)
        {
            var found = tailnet.FirstOrDefault(item => item.Id == device.TailnetDeviceId)
                        ?? tailnet.FirstOrDefault(item => item.Ip == device.TailscaleIp);
            if (found is not null)
            {
                device.TailscaleIp = found.Ip;
                device.DnsName = found.DnsName;
                device.OperatingSystem = string.IsNullOrWhiteSpace(device.OperatingSystem) ? found.OperatingSystem : device.OperatingSystem;
                device.LastSeen = found.LastSeen;
                device.State = found.Online ? DeviceConnectionState.TailscaleOnly : DeviceConnectionState.Offline;
            }
        }
        ReplaceDevices(Config.Devices);
    }

    private async Task SyncSecondaryAsync(CancellationToken cancellationToken)
    {
        if (!Uri.TryCreate(Config.CoordinatorUrl, UriKind.Absolute, out var coordinator)
            || !AgentClient.IsTailscaleIp(coordinator.Host))
        {
            throw new InvalidOperationException("The coordinator URL must use its Tailscale IPv4 address.");
        }
        using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };
        using var request = new HttpRequestMessage(HttpMethod.Get, new Uri(coordinator, "/api/v1/registry"));
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", SecretProtector.Unprotect(Config.ControllerTokenProtected));
        using var response = await client.SendAsync(request, cancellationToken);
        response.EnsureSuccessStatusCode();
        var snapshot = await response.Content.ReadFromJsonAsync<RegistrySnapshot>(JsonDefaults.Options, cancellationToken)
                       ?? throw new InvalidDataException("The command center returned an empty registry.");
        var devices = snapshot.Devices.Select(item => new DeviceRecord
        {
            Id = item.Id,
            Name = item.Name,
            HostName = item.HostName,
            DnsName = item.DnsName,
            TailscaleIp = item.TailscaleIp,
            OperatingSystem = item.OperatingSystem,
            AgentTokenProtected = SecretProtector.Protect(item.AgentToken),
            RustDeskPasswordProtected = SecretProtector.Protect(item.RustDeskPassword),
            Role = item.Role,
            LastSeen = item.LastSeen,
            State = DeviceConnectionState.TailscaleOnly
        }).ToList();
        ReplaceDevices(devices);
    }

    private async Task ProbeAgentAsync(DeviceRecord device, CancellationToken cancellationToken)
    {
        try
        {
            var status = await _agents.GetStatusAsync(device, GetAgentToken(device), cancellationToken);
            device.State = DeviceConnectionState.Online;
            device.LastSeen = DateTimeOffset.UtcNow;
            device.AgentVersion = status.AgentVersion;
            device.AdvertisesExitNode = status.AdvertisesExitNode;
        }
        catch
        {
            device.State = device.State == DeviceConnectionState.TailscaleOnly ? DeviceConnectionState.TailscaleOnly : DeviceConnectionState.Offline;
        }
    }

    private async Task RotateOneAsync(DeviceRecord device, CancellationToken cancellationToken)
    {
        var oldToken = GetAgentToken(device);
        var newToken = SecurityHelpers.CreateToken();
        var newPassword = SecurityHelpers.CreateHumanPassword();
        await _agents.RotateCredentialsAsync(device, oldToken, newToken, newPassword, cancellationToken);
        device.AgentTokenProtected = SecretProtector.Protect(newToken);
        device.RustDeskPasswordProtected = SecretProtector.Protect(newPassword);
        device.PendingCredentialRotation = false;
        await _state.SaveAsync(cancellationToken);
    }

    private void ReplaceDevices(IEnumerable<DeviceRecord> devices)
    {
        var selectedId = SelectedDevice?.Id;
        Devices.Clear();
        foreach (var device in devices.OrderByDescending(device => device.State == DeviceConnectionState.Online).ThenBy(device => device.Name)) Devices.Add(device);
        SelectedDevice = Devices.FirstOrDefault(device => device.Id == selectedId) ?? Devices.FirstOrDefault();
    }

    private void ReplaceInvites()
    {
        Invites.Clear();
        foreach (var invite in Config.Invites.OrderByDescending(invite => invite.CreatedAt)) Invites.Add(invite);
    }

    private void RequirePrimary()
    {
        if (Config.Mode != AdminMode.Primary) throw new InvalidOperationException("Only the primary command center can change network permissions.");
    }

    private static string FindTailscale()
    {
        var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Tailscale", "tailscale.exe");
        return File.Exists(path) ? path : throw new FileNotFoundException("Tailscale is not installed.");
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Changed([CallerMemberName] string? property = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
}
