using System.Net;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;
using System.Net.NetworkInformation;
using Taildesk.Shared;

namespace Taildesk.Admin;

public sealed class CoordinatorServer : IAsyncDisposable
{
    private readonly AdminState _state;
    private readonly TailscaleApiClient _tailscale;
    private WebApplication? _app;

    public CoordinatorServer(AdminState state, TailscaleApiClient tailscale)
    {
        _state = state;
        _tailscale = tailscale;
    }

    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        if (_state.Config.Mode != AdminMode.Primary || !_state.Config.SetupComplete)
        {
            return;
        }
        if (!IPAddress.TryParse(_state.Config.CoordinatorBindAddress, out var address) || !IsTailscaleAddress(address))
        {
            throw new InvalidOperationException("The coordinator must bind to its 100.64.0.0/10 Tailscale IPv4 address.");
        }

        for (var attempt = 0; attempt < 60 && !AddressIsAssigned(address); attempt++)
        {
            await Task.Delay(TimeSpan.FromSeconds(2), cancellationToken);
        }
        if (!AddressIsAssigned(address))
        {
            throw new InvalidOperationException("The coordinator's Tailscale address did not become available within two minutes.");
        }

        var builder = WebApplication.CreateSlimBuilder();
        builder.WebHost.ConfigureKestrel(options => options.Listen(address, _state.Config.CoordinatorPort));
        builder.Services.AddRateLimiter(options =>
        {
            options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
            options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(context =>
                RateLimitPartition.GetFixedWindowLimiter(
                    context.Connection.RemoteIpAddress?.MapToIPv4().ToString() ?? "unknown",
                    _ => new FixedWindowRateLimiterOptions
                    {
                        PermitLimit = 30,
                        Window = TimeSpan.FromMinutes(1),
                        QueueLimit = 0,
                        AutoReplenishment = true
                    }));
        });
        _app = builder.Build();

        _app.UseRateLimiter();
        _app.MapPost("/api/v1/enroll", EnrollAsync);
        _app.MapGet("/api/v1/registry", RegistryAsync);
        await _app.StartAsync(cancellationToken);
    }

    private async Task<IResult> EnrollAsync(EnrollmentRequest request, HttpContext context, CancellationToken cancellationToken)
    {
        var remote = context.Connection.RemoteIpAddress;
        if (remote is null || !IsTailscaleAddress(remote) || !remote.MapToIPv4().ToString().Equals(request.TailscaleIp, StringComparison.OrdinalIgnoreCase))
        {
            return Results.Json(new EnrollmentResponse { Message = "Enrollment must originate from the reported Tailscale address." }, statusCode: 403);
        }

        await _state.InviteGate.WaitAsync(cancellationToken);
        try
        {
            var invite = _state.Config.Invites.FirstOrDefault(item => item.Id == request.InviteId);
            if (invite is null || invite.RedeemedAt.HasValue || invite.IsExpired
                || !SecurityHelpers.FixedTimeEquals(invite.InviteSecretHash, SecurityHelpers.HashToken(request.InviteSecret)))
            {
                return Results.Json(new EnrollmentResponse { Message = "The invitation is invalid, expired, or already used." }, statusCode: 403);
            }

            // A one-use key is normally consumed by `tailscale up`. Revoking it
            // here also closes the edge case where Setup resumed an already
            // enrolled, strictly matching session and therefore did not consume it.
            await _tailscale.RevokeKeyAsync(invite.TailscaleKeyId, cancellationToken);

            var device = _state.Config.Devices.FirstOrDefault(item => item.TailnetDeviceId == request.TailnetDeviceId)
                         ?? new DeviceRecord { Id = Guid.NewGuid() };
            device.TailnetDeviceId = request.TailnetDeviceId;
            device.Name = string.IsNullOrWhiteSpace(invite.DeviceName) ? request.HostName : invite.DeviceName;
            device.HostName = request.HostName;
            device.DnsName = request.DnsName;
            device.TailscaleIp = request.TailscaleIp;
            device.OperatingSystem = request.OperatingSystem;
            device.AgentVersion = request.AgentVersion;
            device.AgentTokenProtected = invite.AgentTokenProtected;
            device.RustDeskPasswordProtected = invite.RustDeskPasswordProtected;
            device.ControllerTokenProtected = invite.ControllerTokenProtected;
            device.Role = invite.Role;
            device.AdvertisesExitNode = invite.AdvertiseExitNode;
            device.State = DeviceConnectionState.Online;
            device.LastSeen = DateTimeOffset.UtcNow;
            if (!_state.Config.Devices.Contains(device)) _state.Config.Devices.Add(device);
            invite.RedeemedAt = DateTimeOffset.UtcNow;
            invite.EnrolledDeviceId = device.Id;
            await _state.SaveAsync(cancellationToken);
            return Results.Ok(new EnrollmentResponse { Accepted = true, Message = "Enrollment complete." });
        }
        finally
        {
            _state.InviteGate.Release();
        }
    }

    private async Task<IResult> RegistryAsync(HttpContext context, CancellationToken cancellationToken)
    {
        context.Response.Headers["Cache-Control"] = "no-store";
        var header = context.Request.Headers.Authorization.ToString();
        var token = header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase) ? header[7..].Trim() : string.Empty;
        await _state.InviteGate.WaitAsync(cancellationToken);
        try
        {
            var controller = _state.Config.Devices.FirstOrDefault(device =>
                device.Role == DeviceRole.ControllerAndManaged
                && !string.IsNullOrWhiteSpace(device.ControllerTokenProtected)
                && SecurityHelpers.FixedTimeEquals(SecretProtector.Unprotect(device.ControllerTokenProtected), token));
            if (controller is null)
            {
                return Results.Unauthorized();
            }

            var remote = context.Connection.RemoteIpAddress;
            if (remote is null || !IsTailscaleAddress(remote) || !remote.MapToIPv4().ToString().Equals(controller.TailscaleIp, StringComparison.OrdinalIgnoreCase))
            {
                return Results.Unauthorized();
            }

            return Results.Ok(new RegistrySnapshot
            {
                Devices = _state.Config.Devices.Select(device => new ControllerDeviceDto
                {
                    Id = device.Id,
                    Name = device.Name,
                    HostName = device.HostName,
                    DnsName = device.DnsName,
                    TailscaleIp = device.TailscaleIp,
                    OperatingSystem = device.OperatingSystem,
                    AgentToken = SecretProtector.Unprotect(device.AgentTokenProtected),
                    RustDeskPassword = SecretProtector.Unprotect(device.RustDeskPasswordProtected),
                    Role = device.Role,
                    LastSeen = device.LastSeen
                }).ToList()
            });
        }
        finally
        {
            _state.InviteGate.Release();
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_app is not null)
        {
            await _app.StopAsync();
            await _app.DisposeAsync();
        }
    }

    private static bool IsTailscaleAddress(IPAddress address)
    {
        var bytes = address.MapToIPv4().GetAddressBytes();
        return bytes[0] == 100 && bytes[1] is >= 64 and <= 127;
    }

    private static bool AddressIsAssigned(IPAddress address) => NetworkInterface.GetAllNetworkInterfaces()
        .SelectMany(network => network.GetIPProperties().UnicastAddresses)
        .Any(item => item.Address.Equals(address));
}
