using System.Windows;

namespace Taildesk.Admin;

public partial class App : System.Windows.Application
{
    private CoordinatorServer? _coordinator;
    private Mutex? _singleInstance;
    private System.Windows.Forms.NotifyIcon? _trayIcon;
    public bool ExitRequested { get; private set; }

    public AdminState State { get; } = new();
    public TailscaleApiClient Tailscale { get; private set; } = null!;
    public AgentClient Agents { get; } = new();
    public TransferManager Transfers { get; } = new();

    private async void Application_Startup(object sender, StartupEventArgs e)
    {
        _singleInstance = new Mutex(true, "Local\\Taildesk.Admin.SingleInstance", out var created);
        if (!created)
        {
            MessageBox.Show("Taildesk is already running.", "Taildesk", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        try
        {
            await State.InitializeAsync();
            Tailscale = new TailscaleApiClient(State);
            var window = new MainWindow(new MainViewModel(State, Tailscale, Agents, Transfers));
            MainWindow = window;
            window.Show();
            CreateTrayIcon();
            try
            {
                await RestartCoordinatorAsync();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Taildesk opened, but the coordinator is not listening yet. Check Tailscale and then save Settings again.\n\n{exception.Message}",
                    "Coordinator unavailable", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        catch (Exception exception)
        {
            MessageBox.Show(exception.Message, "Taildesk could not start", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    public async Task RestartCoordinatorAsync()
    {
        if (_coordinator is not null)
        {
            await _coordinator.DisposeAsync();
            _coordinator = null;
        }
        if (State.Config.Mode == AdminMode.Primary && State.Config.SetupComplete)
        {
            _coordinator = new CoordinatorServer(State, Tailscale);
            await _coordinator.StartAsync();
        }
    }

    public void ShowCommandCenter()
    {
        if (MainWindow is null) return;
        MainWindow.Show();
        if (MainWindow.WindowState == WindowState.Minimized) MainWindow.WindowState = WindowState.Normal;
        MainWindow.Activate();
    }

    public void ExitFromTray()
    {
        ExitRequested = true;
        Shutdown();
    }

    private void CreateTrayIcon()
    {
        var menu = new System.Windows.Forms.ContextMenuStrip();
        menu.Items.Add("Open Taildesk", null, (_, _) => Dispatcher.Invoke(ShowCommandCenter));
        menu.Items.Add(new System.Windows.Forms.ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => Dispatcher.Invoke(ExitFromTray));
        _trayIcon = new System.Windows.Forms.NotifyIcon
        {
            Text = "Taildesk command center",
            Icon = System.Drawing.SystemIcons.Application,
            ContextMenuStrip = menu,
            Visible = true
        };
        _trayIcon.DoubleClick += (_, _) => Dispatcher.Invoke(ShowCommandCenter);
    }

    private async void Application_Exit(object sender, ExitEventArgs e)
    {
        if (_coordinator is not null) await _coordinator.DisposeAsync();
        if (_trayIcon is not null)
        {
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
        }
        _singleInstance?.Dispose();
    }
}
