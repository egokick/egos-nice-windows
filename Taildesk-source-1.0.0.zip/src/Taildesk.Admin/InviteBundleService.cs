using System.IO.Compression;
using System.Text.Json;
using Taildesk.Shared;

namespace Taildesk.Admin;

public sealed record InviteBundleResult(InviteRecord Record, string BundlePath);

public sealed class InviteBundleService
{
    private static readonly string[] SupportedRoots = ["Desktop", "Documents", "Downloads", "Pictures", "Videos"];
    private readonly AdminState _state;
    private readonly TailscaleApiClient _tailscale;

    public InviteBundleService(AdminState state, TailscaleApiClient tailscale)
    {
        _state = state;
        _tailscale = tailscale;
    }

    public async Task<InviteBundleResult> CreateAsync(
        string deviceName,
        DeviceRole role,
        bool advertiseExitNode,
        IReadOnlyCollection<string> allowedRoots,
        CancellationToken cancellationToken = default)
    {
        if (_state.Config.Mode != AdminMode.Primary)
        {
            throw new InvalidOperationException("Only the primary command center can issue invitations.");
        }
        if (string.IsNullOrWhiteSpace(deviceName))
        {
            throw new ArgumentException("Enter a name for the target machine.", nameof(deviceName));
        }

        ArgumentNullException.ThrowIfNull(allowedRoots);
        var distinctRequestedRoots = allowedRoots
            .Where(root => !string.IsNullOrWhiteSpace(root))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();
        var selectedRoots = SupportedRoots
            .Where(root => distinctRequestedRoots.Contains(root, StringComparer.OrdinalIgnoreCase))
            .ToArray();
        if (selectedRoots.Length == 0)
        {
            throw new ArgumentException("Select at least one shared folder for the target machine.", nameof(allowedRoots));
        }
        if (selectedRoots.Length != distinctRequestedRoots.Length)
        {
            throw new ArgumentException("The invitation contains an unsupported shared folder.", nameof(allowedRoots));
        }

        var expectedTailnet = await ReadCurrentTailnetAsync(cancellationToken);
        var authKey = await _tailscale.CreateInviteKeyAsync(role, advertiseExitNode, $"Taildesk invite for {deviceName}", cancellationToken);
        var secret = SecurityHelpers.CreateToken();
        var agentToken = SecurityHelpers.CreateToken();
        var rustDeskPassword = SecurityHelpers.CreateHumanPassword();
        var controllerToken = SecurityHelpers.CreateToken();
        var expires = DateTimeOffset.UtcNow.AddMinutes(15);
        var payload = new InvitePayload
        {
            InviteId = Guid.NewGuid(),
            DeviceName = deviceName.Trim(),
            Role = role,
            ExpiresAt = expires,
            InviteSecret = secret,
            TailscaleAuthKey = authKey.Key,
            AgentToken = agentToken,
            RustDeskPassword = rustDeskPassword,
            ControllerToken = controllerToken,
            CoordinatorUrl = _state.Config.CoordinatorUrl,
            ExpectedTailnet = expectedTailnet,
            AdvertiseExitNode = advertiseExitNode,
            AllowedRoots = selectedRoots
        };

        var record = new InviteRecord
        {
            Id = payload.InviteId,
            DeviceName = payload.DeviceName,
            Role = role,
            InviteSecretHash = SecurityHelpers.HashToken(secret),
            AgentTokenProtected = SecretProtector.Protect(agentToken),
            RustDeskPasswordProtected = SecretProtector.Protect(rustDeskPassword),
            ControllerTokenProtected = SecretProtector.Protect(controllerToken),
            CreatedAt = DateTimeOffset.UtcNow,
            ExpiresAt = expires,
            AdvertiseExitNode = advertiseExitNode,
            TailscaleKeyId = authKey.Id
        };

        Directory.CreateDirectory(_state.Config.InviteOutputDirectory);
        var safeName = new string(payload.DeviceName.Select(character => char.IsLetterOrDigit(character) ? character : '-').ToArray()).Trim('-');
        var output = Path.Combine(_state.Config.InviteOutputDirectory, $"Taildesk-Invite-{safeName}-{payload.InviteId.ToString("N")[..6]}.zip");
        var staging = Path.Combine(Path.GetTempPath(), "Taildesk-Invite", Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(staging);
            CopyDirectory(Path.Combine(AppContext.BaseDirectory, "Payload", "Setup"), staging);
            CopyDirectory(Path.Combine(AppContext.BaseDirectory, "Payload", "Agent"), Path.Combine(staging, "Payload", "Agent"));
            CopyDirectory(Path.Combine(AppContext.BaseDirectory, "Payload", "Admin"), Path.Combine(staging, "Payload", "Admin"));
            await using (var stream = File.Create(Path.Combine(staging, "invite.tdinvite")))
            {
                await JsonSerializer.SerializeAsync(stream, payload, JsonDefaults.Options, cancellationToken);
            }
            await File.WriteAllTextAsync(Path.Combine(staging, "START HERE.txt"),
                "TAILDESK INVITATION\r\n\r\n1. Extract this entire ZIP.\r\n2. Run Taildesk.Setup.exe.\r\n3. Approve the Windows administrator prompt.\r\n\r\nThis invitation is single-use and expires in 15 minutes. Delete the ZIP after installation.\r\n",
                cancellationToken);
            if (File.Exists(output)) File.Delete(output);
            ZipFile.CreateFromDirectory(staging, output, CompressionLevel.SmallestSize, false);
        }
        catch
        {
            try { await _tailscale.RevokeKeyAsync(authKey.Id, CancellationToken.None); } catch { }
            throw;
        }
        finally
        {
            try { Directory.Delete(staging, true); } catch { }
        }

        record.BundlePath = output;
        _state.Config.Invites.Add(record);
        await _state.SaveAsync(cancellationToken);
        return new InviteBundleResult(record, output);
    }

    private static async Task<string> ReadCurrentTailnetAsync(CancellationToken cancellationToken)
    {
        var tailscale = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Tailscale", "tailscale.exe");
        if (!File.Exists(tailscale)) throw new FileNotFoundException("Tailscale is not installed on the command center.");
        var result = await ProcessRunner.RunAsync(tailscale, ["status", "--json"], TimeSpan.FromSeconds(20), cancellationToken);
        if (!result.Succeeded) throw new InvalidOperationException("Could not read the command center's active tailnet: " + result.StandardError.Trim());
        using var document = JsonDocument.Parse(result.StandardOutput);
        var root = document.RootElement;
        var tailnet = root.TryGetProperty("CurrentTailnet", out var current) && current.ValueKind == JsonValueKind.Object
            ? ReadString(current, "Name")
            : string.Empty;
        if (string.IsNullOrWhiteSpace(tailnet))
        {
            tailnet = root.TryGetProperty("MagicDNSSuffix", out var suffix) && suffix.ValueKind == JsonValueKind.String
                ? suffix.GetString() ?? string.Empty
                : string.Empty;
        }
        return !string.IsNullOrWhiteSpace(tailnet)
            ? tailnet
            : throw new InvalidOperationException("Tailscale is not signed in to a tailnet on the command center.");
    }

    private static string ReadString(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? string.Empty
            : string.Empty;

    private static void CopyDirectory(string source, string destination)
    {
        if (!Directory.Exists(source))
        {
            throw new DirectoryNotFoundException($"Published payload is missing: {source}");
        }
        Directory.CreateDirectory(destination);
        foreach (var directory in Directory.EnumerateDirectories(source, "*", SearchOption.AllDirectories))
        {
            Directory.CreateDirectory(Path.Combine(destination, Path.GetRelativePath(source, directory)));
        }
        foreach (var file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
        {
            File.Copy(file, Path.Combine(destination, Path.GetRelativePath(source, file)), true);
        }
    }
}
