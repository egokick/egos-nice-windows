using Taildesk.Shared;

namespace Taildesk.Admin;

public enum AdminMode
{
    Primary,
    Secondary
}

public sealed class AdminConfig
{
    public int SchemaVersion { get; set; } = 1;
    public AdminMode Mode { get; set; } = AdminMode.Primary;
    public bool SetupComplete { get; set; }
    public string Tailnet { get; set; } = "-";
    public string OAuthClientId { get; set; } = string.Empty;
    public string OAuthClientSecretProtected { get; set; } = string.Empty;
    public string CoordinatorBindAddress { get; set; } = string.Empty;
    public int CoordinatorPort { get; set; } = 45830;
    public string CoordinatorUrl { get; set; } = string.Empty;
    public string ControllerTokenProtected { get; set; } = string.Empty;
    public string InviteOutputDirectory { get; set; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Taildesk Invites");
    public string RustDeskPath { get; set; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "RustDesk", "rustdesk.exe");
    public List<DeviceRecord> Devices { get; set; } = [];
    public List<InviteRecord> Invites { get; set; } = [];
}

public sealed class AdminState
{
    private readonly JsonFileStore<AdminConfig> _store = new(AppPaths.AdminConfigFile);
    private readonly SemaphoreSlim _gate = new(1, 1);

    // Enrollment, cancellation, registry snapshots, and device revocation must
    // serialize so a controller cannot receive a half-updated device registry.
    internal SemaphoreSlim InviteGate { get; } = new(1, 1);

    public AdminConfig Config { get; private set; } = new();
    public event EventHandler? Changed;

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        Config = await _store.LoadAsync(cancellationToken);
        var bootstrapPath = Path.Combine(AppPaths.AdminDataDirectory, "bootstrap.json");
        if (File.Exists(bootstrapPath))
        {
            var bootstrap = await new JsonFileStore<AdminBootstrap>(bootstrapPath).LoadAsync(cancellationToken);
            var bootstrapToken = SecretProtector.Unprotect(
                bootstrap.ControllerTokenProtected,
                bootstrap.IsMachineProtected ? SecretScope.LocalMachine : SecretScope.CurrentUser);
            Config.Mode = AdminMode.Secondary;
            Config.SetupComplete = true;
            Config.CoordinatorUrl = bootstrap.CoordinatorUrl;
            Config.ControllerTokenProtected = SecretProtector.Protect(bootstrapToken, SecretScope.CurrentUser);
            await SaveAsync(cancellationToken);
            try { File.Delete(bootstrapPath); } catch { }
        }
    }

    public async Task SaveAsync(CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await _store.SaveAsync(Config, cancellationToken);
        }
        finally
        {
            _gate.Release();
        }
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public DeviceRecord? FindDevice(Guid id) => Config.Devices.FirstOrDefault(device => device.Id == id);
}
