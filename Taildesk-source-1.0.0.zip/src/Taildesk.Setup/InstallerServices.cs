using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Runtime.InteropServices;
using System.Text.Json;
using Taildesk.Shared;

namespace Taildesk.Setup;

public sealed record InstallProgress(int Percent, string Message);

public sealed class ExistingTailscaleSessionException : InvalidOperationException
{
    public ExistingTailscaleSessionException(string message) : base(message) { }
}

public sealed class InstallCoordinator
{
    private const string TailscaleInstallerUrl = "https://pkgs.tailscale.com/stable/tailscale-setup-full-latest.exe";
    private const string RustDeskReleaseApi = "https://api.github.com/repos/rustdesk/rustdesk/releases/latest";
    private readonly InvitePayload _invite;
    private readonly string _bundleDirectory;
    private readonly IProgress<InstallProgress> _progress;
    private readonly HttpClient _http;
    private readonly bool _allowTailscaleReauthentication;
    private readonly InteractiveUserProfile _userProfile;

    public InstallCoordinator(InvitePayload invite, string bundleDirectory, IProgress<InstallProgress> progress, bool allowTailscaleReauthentication = false)
    {
        _invite = invite;
        _bundleDirectory = bundleDirectory;
        _progress = progress;
        _allowTailscaleReauthentication = allowTailscaleReauthentication;
        _userProfile = InteractiveUserProfile.Resolve();
        _http = new HttpClient { Timeout = TimeSpan.FromMinutes(10) };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("Taildesk-Setup/1.0");
    }

    public async Task InstallAsync(CancellationToken cancellationToken)
    {
        EnsureInviteIsValid();
        var canResumeExistingSession = false;
        if (File.Exists(AppPaths.AgentConfigFile))
        {
            var installedState = await new JsonFileStore<AgentConfig>(AppPaths.AgentConfigFile).LoadAsync(cancellationToken);
            if (installedState.CompletedInviteId == _invite.InviteId)
            {
                _progress.Report(new InstallProgress(100, "This invitation is already installed and enrolled."));
                return;
            }
            canResumeExistingSession = installedState.PendingInviteId == _invite.InviteId;
        }
        var tempDirectory = Path.Combine(Path.GetTempPath(), "Taildesk", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tempDirectory);
        try
        {
            _progress.Report(new InstallProgress(4, "Checking the invitation and local payload…"));
            var agentPayload = Path.Combine(_bundleDirectory, "Payload", "Agent");
            if (!File.Exists(Path.Combine(agentPayload, "Taildesk.Agent.exe")))
            {
                throw new FileNotFoundException("The invitation bundle is incomplete (Payload\\Agent is missing).");
            }

            await EnsureTailscaleAsync(tempDirectory, cancellationToken);
            _progress.Report(new InstallProgress(28, "Joining the private Taildesk network…"));
            var tailscale = FindTailscale();
            var existing = await TryReadTailscaleStatusAsync(tailscale, cancellationToken);
            LocalTailscaleSnapshot snapshot;
            if (existing is { Online: true } && canResumeExistingSession)
            {
                if (!ExistingSessionHasExpectedRole(existing))
                {
                    throw new InvalidOperationException("This partial installation is no longer connected to the invitation's exact tailnet and role. Create a new invitation instead of reusing this one.");
                }
                _progress.Report(new InstallProgress(31, "This machine already has the expected Taildesk Tailscale role."));
                snapshot = existing;
            }
            else
            {
                if (existing is { Online: true } && !string.IsNullOrWhiteSpace(existing.Ip))
                {
                    if (!_allowTailscaleReauthentication)
                    {
                        throw new ExistingTailscaleSessionException("This machine is already connected to Tailscale. To consume this single-use invitation and enforce its exact tailnet and role, Taildesk must sign it out and re-enroll it.");
                    }
                    var logout = await ProcessRunner.RunAsync(tailscale, ["logout"], TimeSpan.FromSeconds(30), cancellationToken);
                    EnsureSuccess(logout, "Tailscale could not sign out of the existing session");
                }

                var up = await ProcessRunner.RunAsync(tailscale,
                    ["up", $"--auth-key={_invite.TailscaleAuthKey}", $"--hostname={SafeHostName(_invite.DeviceName)}", "--unattended=true"],
                    TimeSpan.FromMinutes(2), cancellationToken);
                EnsureSuccess(up, "Tailscale could not join the tailnet");
                snapshot = await WaitForExpectedTailscaleSessionAsync(tailscale, cancellationToken);
            }
            if (!ExistingSessionHasExpectedRole(snapshot))
            {
                throw new InvalidOperationException("Tailscale joined, but the resulting tailnet or device tags do not exactly match this invitation.");
            }
            if (string.IsNullOrWhiteSpace(snapshot.Ip))
            {
                throw new InvalidOperationException("Tailscale joined, but did not assign an address.");
            }

            if (_invite.AdvertiseExitNode)
            {
                _progress.Report(new InstallProgress(38, "Enabling this machine as an exit node…"));
                var advertise = await ProcessRunner.RunAsync(tailscale, ["set", "--advertise-exit-node"], TimeSpan.FromSeconds(30), cancellationToken);
                EnsureSuccess(advertise, "Tailscale could not advertise the exit node");
            }

            var rustDesk = await EnsureRustDeskAsync(tempDirectory, cancellationToken);
            await ConfigureRustDeskAsync(rustDesk, cancellationToken);
            await InstallAgentAsync(agentPayload, snapshot.Ip, cancellationToken);
            await ConfigureFirewallAsync(snapshot.Ip, rustDesk, cancellationToken);

            await InstallControllerPayloadAsync(_invite.Role == DeviceRole.ControllerAndManaged, cancellationToken);

            _progress.Report(new InstallProgress(94, "Starting the Taildesk agent…"));
            var start = await ProcessRunner.RunAsync("schtasks.exe", ["/Run", "/TN", "Taildesk Agent"], TimeSpan.FromSeconds(20), cancellationToken);
            EnsureSuccess(start, "The Taildesk agent task could not be started");
            _progress.Report(new InstallProgress(96, "Waiting for the command center to confirm enrollment…"));
            await WaitForEnrollmentAsync(cancellationToken);
            _progress.Report(new InstallProgress(100, "Connected. This machine is ready."));
        }
        finally
        {
            try { Directory.Delete(tempDirectory, true); } catch { }
        }
    }

    private async Task EnsureTailscaleAsync(string tempDirectory, CancellationToken cancellationToken)
    {
        if (File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Tailscale", "tailscale.exe")))
        {
            _progress.Report(new InstallProgress(12, "Tailscale is already installed."));
            return;
        }

        _progress.Report(new InstallProgress(10, "Downloading Tailscale from tailscale.com…"));
        var installer = Path.Combine(tempDirectory, "tailscale-setup.exe");
        await DownloadAsync(TailscaleInstallerUrl, installer, cancellationToken);
        await VerifyPublisherAsync(installer, ["Tailscale"], cancellationToken);
        _progress.Report(new InstallProgress(18, "Installing Tailscale…"));
        var result = await ProcessRunner.RunAsync(installer, ["/quiet", "/norestart"], TimeSpan.FromMinutes(3), cancellationToken);
        EnsureSuccess(result, "Tailscale installation failed");
    }

    private async Task<string> EnsureRustDeskAsync(string tempDirectory, CancellationToken cancellationToken)
    {
        var installed = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "RustDesk", "rustdesk.exe");
        if (File.Exists(installed))
        {
            _progress.Report(new InstallProgress(47, "RustDesk is already installed."));
            return installed;
        }

        _progress.Report(new InstallProgress(43, "Finding the current official RustDesk release…"));
        using var release = await _http.GetFromJsonAsync<JsonDocument>(RustDeskReleaseApi, cancellationToken)
                           ?? throw new InvalidOperationException("RustDesk release metadata was empty.");
        var architecture = RuntimeInformation.ProcessArchitecture == Architecture.Arm64 ? "aarch64" : "x86_64";
        var asset = release.RootElement.GetProperty("assets").EnumerateArray()
            .Select(item => new
            {
                Name = item.GetProperty("name").GetString() ?? string.Empty,
                Url = item.GetProperty("browser_download_url").GetString() ?? string.Empty
            })
            .FirstOrDefault(item => item.Name.Contains(architecture, StringComparison.OrdinalIgnoreCase)
                                    && item.Name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
                                    && !item.Name.Contains("portable", StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"No official RustDesk {architecture} Windows installer was found.");

        if (!Uri.TryCreate(asset.Url, UriKind.Absolute, out var assetUri) || !assetUri.Host.Equals("github.com", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("RustDesk returned an unexpected download location.");
        }

        var installer = Path.Combine(tempDirectory, asset.Name);
        _progress.Report(new InstallProgress(49, $"Downloading {asset.Name}…"));
        await DownloadAsync(asset.Url, installer, cancellationToken);
        await VerifyPublisherAsync(installer, ["RustDesk", "PURSLANE"], cancellationToken);
        _progress.Report(new InstallProgress(56, "Installing RustDesk…"));
        var install = await ProcessRunner.RunAsync(installer, ["--silent-install"], TimeSpan.FromMinutes(3), cancellationToken);
        EnsureSuccess(install, "RustDesk installation failed");

        for (var attempt = 0; attempt < 20 && !File.Exists(installed); attempt++)
        {
            await Task.Delay(500, cancellationToken);
        }

        return File.Exists(installed) ? installed : throw new FileNotFoundException("RustDesk did not appear in Program Files after installation.");
    }

    private async Task ConfigureRustDeskAsync(string rustDesk, CancellationToken cancellationToken)
    {
        _progress.Report(new InstallProgress(61, "Securing RustDesk for direct Tailscale access…"));
        var commands = new[]
        {
            new[] { "--install-service" },
            new[] { "--password", _invite.RustDeskPassword },
            new[] { "--option", "direct-server", "Y" },
            new[] { "--option", "direct-access-port", "21118" },
            new[] { "--option", "whitelist", "100.64.0.0/10" },
            new[] { "--option", "access-mode", "full" },
            new[] { "--option", "enable-keyboard", "Y" },
            new[] { "--option", "enable-clipboard", "Y" },
            new[] { "--option", "enable-file-transfer", "Y" },
            new[] { "--option", "approve-mode", "password" },
            new[] { "--option", "verification-method", "use-permanent-password" },
            new[] { "--option", "allow-only-conn-window-open", "N" },
            new[] { "--option", "allow-logon-screen-password", "Y" },
            new[] { "--option", "enable-lan-discovery", "N" },
            new[] { "--option", "allow-remote-config-modification", "N" },
            new[] { "--option", "allow-remote-cm-modification", "N" },
            new[] { "--option", "enable-trusted-devices", "N" }
        };

        foreach (var command in commands)
        {
            var result = await ProcessRunner.RunAsync(rustDesk, command, TimeSpan.FromSeconds(30), cancellationToken);
            EnsureSuccess(result, $"RustDesk configuration command failed ({command[0]})");
        }
    }

    private async Task InstallAgentAsync(string source, string tailscaleIp, CancellationToken cancellationToken)
    {
        _progress.Report(new InstallProgress(70, "Installing the Taildesk background agent…"));
        var destination = Path.Combine(AppPaths.InstallDirectory, "Agent");
        _ = await ProcessRunner.RunAsync("schtasks.exe", ["/End", "/TN", "Taildesk Agent"], TimeSpan.FromSeconds(15), cancellationToken);
        await Task.Delay(750, cancellationToken);
        CopyDirectory(source, destination);

        var roots = BuildSharedRoots(_invite.AllowedRoots);
        if (roots.Count == 0)
        {
            throw new InvalidOperationException("None of the folders selected in this invitation exists in the signed-in user's profile.");
        }
        var config = new AgentConfig
        {
            DeviceName = _invite.DeviceName,
            Role = _invite.Role,
            BindAddress = tailscaleIp,
            AgentTokenHash = SecurityHelpers.HashToken(_invite.AgentToken),
            MediaSigningKeyProtected = SecretProtector.Protect(SecurityHelpers.CreateToken(), SecretScope.LocalMachine),
            CoordinatorUrl = _invite.CoordinatorUrl,
            PendingInviteId = _invite.InviteId,
            PendingInviteSecretProtected = SecretProtector.Protect(_invite.InviteSecret, SecretScope.LocalMachine),
            AdvertiseExitNode = _invite.AdvertiseExitNode,
            SharedRoots = roots,
            ControllerShortcutPaths =
            [
                Path.Combine(_userProfile.Desktop, "Taildesk.lnk"),
                Path.Combine(_userProfile.Startup, "Taildesk.lnk")
            ]
        };
        await new JsonFileStore<AgentConfig>(AppPaths.AgentConfigFile).SaveAsync(config, cancellationToken);

        var protectDirectory = await ProcessRunner.RunAsync("icacls.exe",
            [AppPaths.AgentDataDirectory, "/inheritance:r", "/grant:r", "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F"],
            TimeSpan.FromSeconds(30), cancellationToken);
        EnsureSuccess(protectDirectory, "Could not secure the agent configuration directory");

        var agentExe = Path.Combine(destination, "Taildesk.Agent.exe");
        var taskCommand = $"\"{agentExe}\"";
        var task = await ProcessRunner.RunAsync("schtasks.exe",
            ["/Create", "/TN", "Taildesk Agent", "/SC", "ONSTART", "/RU", "SYSTEM", "/RL", "HIGHEST", "/TR", taskCommand, "/F"],
            TimeSpan.FromSeconds(30), cancellationToken);
        EnsureSuccess(task, "Could not create the Taildesk Agent startup task");

        const string taskSettings = "$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 20 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Seconds 0); Set-ScheduledTask -TaskName 'Taildesk Agent' -Settings $s | Out-Null";
        var settings = await ProcessRunner.RunAsync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", taskSettings],
            TimeSpan.FromSeconds(30), cancellationToken);
        EnsureSuccess(settings, "Could not apply Taildesk Agent recovery settings");
    }

    private async Task ConfigureFirewallAsync(string tailscaleIp, string rustDesk, CancellationToken cancellationToken)
    {
        _progress.Report(new InstallProgress(80, "Restricting inbound access to the Tailscale interface…"));
        var agent = Path.Combine(AppPaths.InstallDirectory, "Agent", "Taildesk.Agent.exe");
        foreach (var rule in new[] { "Taildesk Agent (Tailscale only)", "RustDesk Direct (Tailscale only)" })
        {
            _ = await ProcessRunner.RunAsync("netsh.exe", ["advfirewall", "firewall", "delete", "rule", $"name={rule}"], TimeSpan.FromSeconds(20), cancellationToken);
        }
        _ = await ProcessRunner.RunAsync("netsh.exe",
            ["advfirewall", "firewall", "delete", "rule", "name=all", "dir=in", $"program={rustDesk}"],
            TimeSpan.FromSeconds(20), cancellationToken);

        var agentRule = await ProcessRunner.RunAsync("netsh.exe",
            ["advfirewall", "firewall", "add", "rule", "name=Taildesk Agent (Tailscale only)", "dir=in", "action=allow", "protocol=TCP", "localport=45831", $"localip={tailscaleIp}", "remoteip=100.64.0.0/10", $"program={agent}", "profile=any", "enable=yes"],
            TimeSpan.FromSeconds(30), cancellationToken);
        EnsureSuccess(agentRule, "Could not create the Taildesk firewall rule");

        var rustDeskRule = await ProcessRunner.RunAsync("netsh.exe",
            ["advfirewall", "firewall", "add", "rule", "name=RustDesk Direct (Tailscale only)", "dir=in", "action=allow", "protocol=TCP", "localport=21118", $"localip={tailscaleIp}", "remoteip=100.64.0.0/10", $"program={rustDesk}", "profile=any", "enable=yes"],
            TimeSpan.FromSeconds(30), cancellationToken);
        EnsureSuccess(rustDeskRule, "Could not create the RustDesk firewall rule");
    }

    private async Task InstallControllerPayloadAsync(bool createShortcuts, CancellationToken cancellationToken)
    {
        _progress.Report(new InstallProgress(87, "Installing controller tools for this machine…"));
        var source = Path.Combine(_bundleDirectory, "Payload", "Admin");
        if (!File.Exists(Path.Combine(source, "Taildesk.Admin.exe")))
        {
            throw new FileNotFoundException("This controller invite is missing Payload\\Admin.");
        }

        var destination = Path.Combine(AppPaths.InstallDirectory, "Admin");
        CopyDirectory(source, destination);
        var bootstrap = new AdminBootstrap
        {
            CoordinatorUrl = _invite.CoordinatorUrl,
            ControllerTokenProtected = SecretProtector.Protect(_invite.ControllerToken, SecretScope.LocalMachine),
            DeviceName = _invite.DeviceName,
            IsMachineProtected = true
        };
        var bootstrapPath = Path.Combine(_userProfile.LocalAppData, "Taildesk", "Admin", "bootstrap.json");
        await new JsonFileStore<AdminBootstrap>(bootstrapPath).SaveAsync(bootstrap, cancellationToken);
        if (createShortcuts)
        {
            CreateShortcut(Path.Combine(destination, "Taildesk.Admin.exe"), "Taildesk", _userProfile.Desktop);
            CreateShortcut(Path.Combine(destination, "Taildesk.Admin.exe"), "Taildesk", _userProfile.Startup);
        }
    }

    private async Task<LocalTailscaleSnapshot> ReadTailscaleStatusAsync(string tailscale, CancellationToken cancellationToken)
    {
        var result = await ProcessRunner.RunAsync(tailscale, ["status", "--json"], TimeSpan.FromSeconds(30), cancellationToken);
        EnsureSuccess(result, "Tailscale status was unavailable");
        using var document = JsonDocument.Parse(result.StandardOutput);
        var root = document.RootElement;
        var self = root.GetProperty("Self");
        var ips = self.GetProperty("TailscaleIPs").EnumerateArray().Select(value => value.GetString() ?? string.Empty).ToArray();
        return new LocalTailscaleSnapshot
        {
            DeviceId = self.TryGetProperty("ID", out var id) ? id.GetString() ?? string.Empty : string.Empty,
            DnsName = self.TryGetProperty("DNSName", out var dns) ? (dns.GetString() ?? string.Empty).TrimEnd('.') : string.Empty,
            Ip = ips.FirstOrDefault(ip => ip.Contains('.')) ?? ips.FirstOrDefault() ?? string.Empty,
            Online = true,
            Tailnet = ReadTailnet(root),
            Tags = self.TryGetProperty("Tags", out var tags) && tags.ValueKind == JsonValueKind.Array
                ? tags.EnumerateArray().Select(tag => tag.GetString() ?? string.Empty).ToArray()
                : []
        };
    }

    private async Task<LocalTailscaleSnapshot> WaitForExpectedTailscaleSessionAsync(string tailscale, CancellationToken cancellationToken)
    {
        LocalTailscaleSnapshot? last = null;
        for (var attempt = 0; attempt < 20; attempt++)
        {
            try
            {
                last = await ReadTailscaleStatusAsync(tailscale, cancellationToken);
                if (!string.IsNullOrWhiteSpace(last.Ip) && ExistingSessionHasExpectedRole(last)) return last;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                // The Windows service can take a few seconds to publish the new
                // self identity and tags after `tailscale up` returns.
            }
            await Task.Delay(TimeSpan.FromSeconds(1.5), cancellationToken);
        }
        return last ?? await ReadTailscaleStatusAsync(tailscale, cancellationToken);
    }

    private async Task<LocalTailscaleSnapshot?> TryReadTailscaleStatusAsync(string tailscale, CancellationToken cancellationToken)
    {
        try
        {
            var result = await ProcessRunner.RunAsync(tailscale, ["status", "--json"], TimeSpan.FromSeconds(15), cancellationToken);
            if (!result.Succeeded || string.IsNullOrWhiteSpace(result.StandardOutput)) return null;
            using var document = JsonDocument.Parse(result.StandardOutput);
            var root = document.RootElement;
            var backendState = root.TryGetProperty("BackendState", out var state) ? state.GetString() ?? string.Empty : string.Empty;
            if (!backendState.Equals("Running", StringComparison.OrdinalIgnoreCase)) return null;
            var self = root.GetProperty("Self");
            var ips = self.GetProperty("TailscaleIPs").EnumerateArray().Select(value => value.GetString() ?? string.Empty).ToArray();
            return new LocalTailscaleSnapshot
            {
                Ip = ips.FirstOrDefault(ip => ip.Contains('.')) ?? string.Empty,
                Online = true,
                Tailnet = ReadTailnet(root),
                Tags = self.TryGetProperty("Tags", out var tags) && tags.ValueKind == JsonValueKind.Array
                    ? tags.EnumerateArray().Select(tag => tag.GetString() ?? string.Empty).ToArray()
                    : []
            };
        }
        catch
        {
            return null;
        }
    }

    private async Task WaitForEnrollmentAsync(CancellationToken cancellationToken)
    {
        var store = new JsonFileStore<AgentConfig>(AppPaths.AgentConfigFile);
        for (var attempt = 0; attempt < 60; attempt++)
        {
            var state = await store.LoadAsync(cancellationToken);
            if (!state.PendingInviteId.HasValue) return;
            await Task.Delay(TimeSpan.FromSeconds(2), cancellationToken);
        }
        throw new TimeoutException("The agent is installed and will keep retrying, but the command center did not confirm enrollment within two minutes. Make sure the command-center app is running and the Taildesk tailnet policy is active.");
    }

    private bool ExistingSessionHasExpectedRole(LocalTailscaleSnapshot snapshot)
    {
        var expected = _invite.Role == DeviceRole.ControllerAndManaged ? "tag:taildesk-controller" : "tag:taildesk-managed";
        var opposite = _invite.Role == DeviceRole.ControllerAndManaged ? "tag:taildesk-managed" : "tag:taildesk-controller";
        var hasExitTag = snapshot.Tags.Contains("tag:taildesk-exit", StringComparer.OrdinalIgnoreCase);
        return snapshot.Tags.Contains(expected, StringComparer.OrdinalIgnoreCase)
               && !snapshot.Tags.Contains(opposite, StringComparer.OrdinalIgnoreCase)
               && hasExitTag == _invite.AdvertiseExitNode
               && snapshot.Tailnet.Equals(_invite.ExpectedTailnet, StringComparison.OrdinalIgnoreCase);
    }

    private static string ReadTailnet(JsonElement root)
    {
        if (root.TryGetProperty("CurrentTailnet", out var current) && current.ValueKind == JsonValueKind.Object
            && current.TryGetProperty("Name", out var name) && name.ValueKind == JsonValueKind.String)
        {
            return name.GetString() ?? string.Empty;
        }
        return root.TryGetProperty("MagicDNSSuffix", out var suffix) && suffix.ValueKind == JsonValueKind.String
            ? suffix.GetString() ?? string.Empty
            : string.Empty;
    }

    private async Task DownloadAsync(string url, string destination, CancellationToken cancellationToken)
    {
        using var response = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
        response.EnsureSuccessStatusCode();
        await using var source = await response.Content.ReadAsStreamAsync(cancellationToken);
        await using var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 1024, true);
        await source.CopyToAsync(output, 1024 * 1024, cancellationToken);
    }

    private static async Task VerifyPublisherAsync(string file, string[] allowedPublisherTerms, CancellationToken cancellationToken)
    {
        const string command = "$s=Get-AuthenticodeSignature -LiteralPath $args[0]; if($s.Status -ne 'Valid'){Write-Error ('Invalid Authenticode signature: '+$s.Status); exit 9}; $s.SignerCertificate.Subject";
        var result = await ProcessRunner.RunAsync("powershell.exe",
            ["-NoProfile", "-NonInteractive", "-Command", command, file], TimeSpan.FromSeconds(45), cancellationToken);
        if (!result.Succeeded || !allowedPublisherTerms.Any(term => result.StandardOutput.Contains(term, StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidDataException($"The downloaded installer did not have an expected, valid publisher signature ({Path.GetFileName(file)}). Setup will not run it.");
        }
    }

    private Dictionary<string, string> BuildSharedRoots(IEnumerable<string> requested)
    {
        var known = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["Desktop"] = _userProfile.Desktop,
            ["Documents"] = _userProfile.Documents,
            ["Downloads"] = _userProfile.Downloads,
            ["Pictures"] = _userProfile.Pictures,
            ["Videos"] = _userProfile.Videos
        };
        return requested.Where(known.ContainsKey)
            .Select(name => new KeyValuePair<string, string>(name, known[name]))
            .Where(pair => Directory.Exists(pair.Value))
            .ToDictionary(pair => pair.Key, pair => pair.Value, StringComparer.OrdinalIgnoreCase);
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var directory in Directory.EnumerateDirectories(source, "*", SearchOption.AllDirectories))
        {
            Directory.CreateDirectory(Path.Combine(destination, Path.GetRelativePath(source, directory)));
        }
        foreach (var file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
        {
            File.Copy(file, Path.Combine(destination, Path.GetRelativePath(source, file)), true);
        }
    }

    private static string FindTailscale()
    {
        var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Tailscale", "tailscale.exe");
        return File.Exists(path) ? path : throw new FileNotFoundException("Tailscale was installed but tailscale.exe was not found.");
    }

    private static string SafeHostName(string value)
    {
        var safe = new string(value.ToLowerInvariant().Select(character => char.IsLetterOrDigit(character) ? character : '-').ToArray()).Trim('-');
        return string.IsNullOrWhiteSpace(safe) ? Environment.MachineName.ToLowerInvariant() : safe[..Math.Min(safe.Length, 63)];
    }

    private void EnsureInviteIsValid()
    {
        var supportedRoots = new HashSet<string>(["Desktop", "Documents", "Downloads", "Pictures", "Videos"], StringComparer.OrdinalIgnoreCase);
        if (_invite.SchemaVersion != 1 || _invite.InviteId == Guid.Empty || string.IsNullOrWhiteSpace(_invite.TailscaleAuthKey)
            || string.IsNullOrWhiteSpace(_invite.ExpectedTailnet)
            || string.IsNullOrWhiteSpace(_invite.AgentToken) || string.IsNullOrWhiteSpace(_invite.InviteSecret)
            || _invite.AllowedRoots is null || _invite.AllowedRoots.Length == 0
            || _invite.AllowedRoots.Distinct(StringComparer.OrdinalIgnoreCase).Count() != _invite.AllowedRoots.Length
            || _invite.AllowedRoots.Any(root => !supportedRoots.Contains(root)))
        {
            throw new InvalidDataException("This is not a valid Taildesk invitation.");
        }
        if (_invite.ExpiresAt <= DateTimeOffset.UtcNow)
        {
            throw new InvalidDataException("This Taildesk invitation has expired. Create a new one on the command center.");
        }
    }

    private void EnsureSuccess(ProcessResult result, string message)
    {
        if (!result.Succeeded && result.ExitCode != 3010)
        {
            var detail = $"{result.StandardError.Trim()} {result.StandardOutput.Trim()}";
            foreach (var secret in new[] { _invite.TailscaleAuthKey, _invite.AgentToken, _invite.InviteSecret, _invite.ControllerToken, _invite.RustDeskPassword })
            {
                if (!string.IsNullOrEmpty(secret)) detail = detail.Replace(secret, "[redacted]", StringComparison.Ordinal);
            }
            throw new InvalidOperationException($"{message}: {detail}".Trim());
        }
    }

    private static void CreateShortcut(string target, string name, string directory)
    {
        Directory.CreateDirectory(directory);
        var shellType = Type.GetTypeFromProgID("WScript.Shell") ?? throw new InvalidOperationException("Windows Script Host is unavailable.");
        dynamic shell = Activator.CreateInstance(shellType)!;
        dynamic shortcut = shell.CreateShortcut(Path.Combine(directory, name + ".lnk"));
        shortcut.TargetPath = target;
        shortcut.WorkingDirectory = Path.GetDirectoryName(target);
        shortcut.Description = "Taildesk command center";
        shortcut.Save();
        Marshal.FinalReleaseComObject(shortcut);
        Marshal.FinalReleaseComObject(shell);
    }

    private sealed class LocalTailscaleSnapshot
    {
        public string DeviceId { get; init; } = string.Empty;
        public string DnsName { get; init; } = string.Empty;
        public string Ip { get; init; } = string.Empty;
        public bool Online { get; init; }
        public string Tailnet { get; init; } = string.Empty;
        public string[] Tags { get; init; } = [];
    }
}
